document.addEventListener('DOMContentLoaded', () => {
    const calculatorInput = document.getElementById('calculator-input');
    const calculatorOutput = document.getElementById('calculator-output');
    const buttons = document.querySelectorAll('.button');

    let currentInput = '';
    let result = '';

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const buttonText = button.textContent;

            if (button.classList.contains('number') || button.classList.contains('operator')) {
                // Handle number and operator input
                if (buttonText === '×') { // Replace '×' with '*' for evaluation
                    currentInput += '*';
                } else if (buttonText === '÷') { // Replace '÷' with '/' for evaluation
                    currentInput += '/';
                } else if (buttonText === '√') { // Handle square root
                    // This is more complex; you might want to handle it as a function or immediately calculate
                    // For now, let's just append it, but actual eval needs care.
                    currentInput += 'sqrt(';
                } else if (buttonText === '±') { // Handle positive/negative toggle
                    // This requires parsing the last number in the input
                    alert("Plus/minus functionality not fully implemented in this basic example.");
                } else {
                    currentInput += buttonText;
                }
                calculatorInput.textContent = currentInput;
            } else if (button.classList.contains('function')) {
                // Handle function buttons (ans, del, clear)
                if (buttonText === 'clear') {
                    currentInput = '';
                    result = '';
                    calculatorInput.textContent = '';
                    calculatorOutput.textContent = '0'; // Or empty string
                } else if (buttonText === 'del') {
                    currentInput = currentInput.slice(0, -1);
                    calculatorInput.textContent = currentInput;
                } else if (buttonText === 'ans') {
                    // Append the last calculated result to the input
                    if (result !== '') {
                        currentInput += result;
                        calculatorInput.textContent = currentInput;
                    }
                }
            } else if (button.classList.contains('enter')) {
                // Handle ENTER button
                try {
                    // Use eval() with caution for user input due to security risks.
                    // For a real-world app, consider a safer math expression parser.
                    // Also, handle specific operations like sqrt()
                    let expressionToEvaluate = currentInput.replace(/sqrt\(([^)]+)\)/g, 'Math.sqrt($1)');
                    result = eval(expressionToEvaluate);
                    calculatorOutput.textContent = result;
                    currentInput = String(result); // Set current input to the result for further operations
                } catch (error) {
                    calculatorOutput.textContent = 'Error';
                    console.error("Calculation error:", error);
                    currentInput = ''; // Clear input on error
                }
            }
        });
    });

    // Initialize display
    calculatorInput.textContent = '';
    calculatorOutput.textContent = '0';
});