import React from 'react';

const Header = () => {
  return (
    <header className="bg-white shadow-md p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">Royal Phoenicia</h1>
      <nav className="space-x-4">
        <a href="#" className="text-gray-700">Home</a>
        <a href="#" className="text-gray-700">Rooms</a>
        <a href="#" className="text-gray-700">Gallery</a>
        <a href="#" className="text-gray-700">Contact</a>
      </nav>
    </header>
  );
};

export default Header;