import React from 'react';

const HeroSection = () => {
  return (
    <section className="bg-cover bg-center h-screen text-white flex items-center justify-center" style={{ backgroundImage: 'url(/assets/hero.jpg)' }}>
      <div className="text-center">
        <h1 className="text-5xl font-bold mb-4">Welcome to Royal Phoenicia</h1>
        <p className="text-lg">Experience luxury and comfort in the heart of the city</p>
      </div>
    </section>
  );
};

export default HeroSection;