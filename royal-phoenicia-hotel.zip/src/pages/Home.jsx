import React from 'react';
import MainLayout from '../layout/MainLayout';
import HeroSection from '../components/HeroSection';
import Footer from '../components/Footer';

const Home = () => {
  return (
    <MainLayout>
      <HeroSection />
      {/* Add other components here */}
      <Footer />
    </MainLayout>
  );
};

export default Home;