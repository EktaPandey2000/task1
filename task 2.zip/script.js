function convert() {
  const degrees = parseFloat(document.getElementById("degrees").value);
  const type = document.getElementById("type").value;
  const result = document.getElementById("result");

  if (isNaN(degrees)) {
    result.textContent = "Invalid input";
    return;
  }

  if (type === "fahrenheit") {
    const celsius = ((degrees - 32) * 5) / 9;
    result.textContent = celsius.toFixed(4) + " °C";
  } else {
    const fahrenheit = (degrees * 9) / 5 + 32;
    result.textContent = fahrenheit.toFixed(4) + " °F";
  }
}